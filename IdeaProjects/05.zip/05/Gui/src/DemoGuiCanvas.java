
public class DemoGuiCanvas {

    public void demo() {
        Canvas canvas = new Canvas();
        canvas.show();
    }

    public static void main(String[] args) {
        DemoGuiCanvas gui = new DemoGuiCanvas();
        gui.demo();
    }

}
